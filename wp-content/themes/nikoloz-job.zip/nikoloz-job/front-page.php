<?php get_header(); ?>
    <?php get_template_part('template-parts/frontpage/section', 'video'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'vacancy'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'testimonials'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'whywe'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'advance'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'photo-gallery'); ?>
    <?php get_template_part('template-parts/frontpage/section', 'contacts'); ?>
<?php get_footer(); ?>
