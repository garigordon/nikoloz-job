<div class="masthead">
    <video class="background-video jquery-background-video is-visible is-playing" poster="<?php bloginfo('template_url'); ?>/images/bg_header_xl.jpg" loop="true" muted autoplay>
        <source src="<?php bloginfo('template_url') ?>/media/bg-video.mp4" type="video/mp4">
    </video>
    <div class="container">
        <div class="container promo-widget">
            <h2 class="promo-widget-text">Трудоустройство за границей</h2>
        </div>
        <div class="container masthead-footer text-center">
            <a href="#" class="btn btn-primary btn-lg  text-uppercase d-none d-md-inline">Вакансии</a>
        </div>
    </div>
</div>

