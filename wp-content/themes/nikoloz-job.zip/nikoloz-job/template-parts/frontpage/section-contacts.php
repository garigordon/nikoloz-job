<section class="section section-contacts">
    <div class="container">
        <div class="row-line">
            <div class="contacts-item">
                <i class="fas icon icon-map-marker-alt"></i>
                <p>г. Харьков, пер.</p>
                <p>Молчановский 29, оф. 27 А</p>
            </div>
            <div class="contacts-item">
                <i class="fa icon icon-phone"></i>
                <p>+38-095-532-25-64</p>
                <p>+38-063-228-18-78</p>
                <p>+38-098-90-100-97</p>
            </div>
            <div class="contacts-item">
                <i class="far icon icon-envelope"></i>
                <p><a href="#">nikolozjob@ukr.net</a></p>
            </div>
        </div>
    </div>
</section>