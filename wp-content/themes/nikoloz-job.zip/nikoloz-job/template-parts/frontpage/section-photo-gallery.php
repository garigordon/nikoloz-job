<section class="section section-photo-gallery">
    <div class="container">
        <div class="section-heading">
            <h2 class="heading-text"><a href="#">Фотогалерея</a></h2>
            <hr class="lines">
        </div>
    </div>
    <div class="row-line photo-gallery">
        <a class="photo-gallery-item" data-fancybox="images" href="<?php bloginfo('template_url') ?>/images/dscn6543.jpg"><figure><img src="<?php bloginfo('template_url') ?>/images/dscn6543.jpg" alt="NIKOLOZ-JOB" title="NIKOLOZ-JOB" /></figure></a>
        <a class="photo-gallery-item" data-fancybox="images" href="<?php bloginfo('template_url') ?>/images/dscn6543.jpg"><figure><img src="<?php bloginfo('template_url') ?>/images/dscn6543.jpg" alt="NIKOLOZ-JOB" title="NIKOLOZ-JOB" /></figure></a>
        <a class="photo-gallery-item" data-fancybox="images" href="<?php bloginfo('template_url') ?>/images/dscn6543.jpg"><figure><img src="<?php bloginfo('template_url') ?>/images/dscn6543.jpg" alt="NIKOLOZ-JOB" title="NIKOLOZ-JOB" /></figure></a>
    </div>
</section>
