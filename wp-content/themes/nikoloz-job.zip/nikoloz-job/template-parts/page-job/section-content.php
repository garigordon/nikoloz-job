<section class="section section-content">
	<div class="container site-content">
		<div class="page-block">
			<?php the_content(); ?>
		</div>
	</div>		
</section>