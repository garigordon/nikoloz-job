<div class="masthead">
    <div class="page-title container">
        <h1><?php the_title(); ?></h1>
    </div>
    <div class="container">
        <ul class="breadcrumbs">
            <?php the_breadcrumb() ?>
        </ul>
    </div>
</div>