    </div>
    <footer class="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row-line">
                    <div class="footer-item">
                        <h3>Работа</h3>
                        <ul class="footer-links">
                            <li><a href="#">Сбор клубники на фермах в Финляндии</a></li>
                            <li><a href="#">Сбор черники, грибов, морошки в Финляндии</a></li>
                            <li><a href="#">Работа на фермах в Финляндии</a></li>
                            <li><a href="#">Упаковка продукции в Чехии</a></li>
                        </ul>
                    </div>
                    <div class="footer-item">
                        <h3>Информация</h3>
                        <ul class="footer-links">
                            <li><a href="#">Контакты</a></li>
                            <li><a href="#">Отзывы</a></li>
                            <li><a href="#">Новости</a></li>
                            <li><a href="#">Статьи</a></li>
                            <li><a href="#">Фотогалерея</a></li>
                            <li><a href="#">Видео галерея</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <p class="copyright">Copyright © 2019 nikoloz job Все права защищены</p>
            </div>
        </div>
    </footer>
    <?php wp_footer() ?>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
</body>
</html>
